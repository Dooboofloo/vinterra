# vinterra:world/weather/changed
# Completes a weather-state transition

scoreboard players set #timer vin.weather 0

function vinterra:world/weather/roll_duration
function vinterra:world/weather/apply_current
function vinterra:world/weather/announce_current

# Weather changes affect every initialized living player's warmth target
execute as @a[predicate=vinterra:player/participating] run function vinterra:player/request_recalc

return 1