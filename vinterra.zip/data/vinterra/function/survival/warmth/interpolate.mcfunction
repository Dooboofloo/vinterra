# vinterra:survival/warmth/interpolate
# Interpolates target player's effective warmth toward their target warmth
# Must be executed as the player

# Debug lock
execute if entity @s[tag=vin.test_lock_warmth] run return 0

# Delta = target - effective
scoreboard players operation @s vin.warmth_tmp = @s vin.warmth_target
scoreboard players operation @s vin.warmth_tmp -= @s vin.warmth_effective

# Already at target
execute if score @s vin.warmth_tmp matches 0 run return 0

# Begin with absolute magnitude of the delta
scoreboard players operation @s vin.warmth_step = @s vin.warmth_tmp
execute if score @s vin.warmth_step matches ..-1 run scoreboard players operation @s vin.warmth_step *= #-1 vin.warmth_meta

# Scale the unsigned magnitude, using different thermal scales
execute if score @s vin.warmth_tmp matches ..-1 run scoreboard players operation @s vin.warmth_step /= #cooling_smoothing vin.warmth_meta
execute if score @s vin.warmth_tmp matches 1.. run scoreboard players operation @s vin.warmth_step /= #warming_smoothing vin.warmth_meta

# Restore the original negative sign when cooling (prevents asymmetric interpolation due to integer division)
execute if score @s vin.warmth_tmp matches ..-1 run scoreboard players operation @s vin.warmth_step *= #-1 vin.warmth_meta

# Guarantee convergence despite integer division
execute if score @s vin.warmth_tmp matches 1.. if score @s vin.warmth_step matches ..0 run scoreboard players set @s vin.warmth_step 1
execute if score @s vin.warmth_tmp matches ..-1 if score @s vin.warmth_step matches 0.. run scoreboard players set @s vin.warmth_step -1

scoreboard players operation @s vin.warmth_effective += @s vin.warmth_step