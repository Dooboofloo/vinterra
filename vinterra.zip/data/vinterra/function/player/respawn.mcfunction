# vinterra:player/respawn
# Resets player-owned variables
# Executed as a player when they respawn

## vinterra:survival/comfort
# Reset total Comfort
scoreboard players set @s vin.comfort 0
scoreboard players set @s vin.comfort_blocks 0
scoreboard players set @s vin.comfort_equipment 0

# Reset wetness
scoreboard players set @s vin.wetness 0

# Reset environmental isolation
scoreboard players set @s vin.shelter 0

# Reset environmental coverage state
tag @s remove vin.player_covered

## vinterra:survival/warmth
# Reset warmth and other related values
scoreboard players operation @s vin.warmth_target = #warmth_default vin.player_meta
scoreboard players operation @s vin.warmth_effective = #warmth_default vin.player_meta

# Set player grace period timer
scoreboard players operation @s vin.player_grace_counter = #warmth_grace_period vin.player_meta

scoreboard players set @s vin.block_heat_raw 0
scoreboard players set @s vin.block_heat_total 0

scoreboard players set @s vin.block_cold_raw 0
scoreboard players set @s vin.block_cold_total 0

# Reset warmth band
scoreboard players reset @s vin.warmth_band

# Reset cold exposure
function vinterra:survival/warmth/cold_exposure/reset

## Request urgent survival recalculation
function vinterra:player/request_recalc

tellraw @a[tag=vin.debug_viewer] [{text:"[Player] Player Respawned: "}, {selector:"@s"}]